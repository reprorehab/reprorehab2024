# This is an exercise involving exploratory analysis.
# Goal: To perform repeated-measures ANOVA for 18 variables, in parallel. The outcome variable is "blood flow in an arterial territory". There are 18 arterial territories.
# There are 2 fixed factors. Each factor has 2 levels. "Time" is the repeated factor (within-subject factor) and has 2 levels.
# The dataframe should be in a long format, with all outcomes in a single column "outcome"
# The columns  are: "subject", "RecordID", group1sub2chr",  "rand1sub2supra", "time" and "outcome".     
# In this example, in the column "time", "before" is labeled as for each territory as "Territoryxyz_1 and "after is labeled as "Territoryxyz_2"

#1.1. Set directory ----

#1.2. Libraries ----
library(nlme)
library(dplyr)
library(readxl)
library(janitor)

#1.3. Read, prepare and check files ----
data=read_excel("ASL0503.xlsx")
#Check the structure (sanity check - if numeric variables are classified as numeric, if categorical are classified as categorical)
str(data)

##1.4. Prepare data ----
#Created file data1 (keeping the original file data = ASL0503) ---
data1 <- data
str(data1)

#Remove unnecessary columns

data1 <- data1[, -c(44, 45, 46, 47)]  # Removes  columns 45 to 47

#data1 now has 43 columns

# create data2 to rename columns in data2
data2 <- data1

# Rename all the columns
names(data2)[8] <- "GlobalLEST1" #renamed GLOBAL_LESADO_PRE to GlobalLEST1
names(data2)[9] <- "GlobalLEST2" 
names(data2)[10] <- "ACALEST1" 
names(data2)[11] <- "ACALEST2"
names(data2)[12] <- "AChALEST1" 
names(data2)[13] <- "AChALEST2" 
names(data2)[14] <- "LEPTOACAT1" 
names(data2)[15] <- "LEPTOACAT2"
names(data2)[16] <- "LEPTOMCAT1" 
names(data2)[17] <- "LEPTOMCAT2"  
names(data2)[18] <- "LEPTOPCAT1" 
names(data2)[19] <- "LEPTOPCAT2" 
names(data2)[20] <- "MCAT1" 
names(data2)[21] <- "MCAT2" 
names(data2)[22] <- "POCAT1" 
names(data2)[23] <- "POCAT2" 
names(data2)[24] <- "InsT1" 
names(data2)[25] <- "InsT2" 
names(data2)[26] <- "CaudT1" 
names(data2)[27] <- "CaudT2" 
names(data2)[28] <- "LentT1" 
names(data2)[29] <- "LentT2" 
names(data2)[30] <- "INTCapsT1" 
names(data2)[31] <- "INTCapsT2"
names(data2)[32] <- "M1T1" 
names(data2)[33] <- "M1T2"
names(data2)[34] <- "M2T1" 
names(data2)[35] <- "M2T2"
names(data2)[36] <- "M3T1" 
names(data2)[37] <- "M3T2"
names(data2)[38] <- "M4T1" 
names(data2)[39] <- "M4T2"
names(data2)[40] <- "M5T1" 
names(data2)[41] <- "M5T2"
names(data2)[42] <- "M6T1" 
names(data2)[43] <- "M6T2"

#pivot columns
library(tidyr)
data2.long <- pivot_longer(
  data2, 
  cols = 8:43,  # Selects columns 8 to 43 explicitly
  names_to = "time", 
  values_to = "outcome"
)

View(data2.long)
str(data2.long)

#Conversions and checks
#Convert 'Record ID' (categorical) into a numeric subject ID
#as.numeric(...): Converts these categories into numbers (1, 2, 3, ..., 34).
#factor(data1.long$Record ID): Converts the "Record ID" column into a factor where each unique value is assigned a category.

data2.long$subject <- as.numeric(factor(data2.long$`Record ID`))


#Make sure that "outcome" is a numerical variable 
#as.character(outcome) → Converts factor levels to character strings (if outcome is a factor).
#as.numeric(...) → Converts character values to numeric values.
#Why is this Needed?
#If outcome is a factor, directly using as.numeric(outcome) will return incorrect values (underlying factor codes).
#Converting to character first ensures the correct numeric conversion.

data2.long <- data2.long %>%
  mutate(outcome = as.numeric(as.character(outcome)))


#2.1 Prepare the data to build list ----
# Ensure outcome is numeric
data2.long$outcome <- as.numeric(data2.long$outcome)

data4.long <- data2.long 

# Create a new column that removes the last character from "time" but keeps the distinction of the factor (this column will indicate the factor=arterial territory, without the #levels pre/post)

data4.long <- data4.long %>%
  mutate(time_group = sub("[12]$", "", time))  # Creates column time_group, that has the same labels of column "time", except for digits 1 and 2 at the end of the names of each territory.

# To split the dataframe, added a column "time_group"
df_merged <- data4.long %>%
  arrange(subject, time_group, time)  # Ensure correct ordering

View(df_merged)

# Split df_merged into a list of tables based on unique values of variable time_group = #arterial territory 
#library(dplyr)

split_tables <- split(df_merged, df_merged$time_group)

#In the Environment, the list split_tables was created. In this list, each element is a separate table.

# View an example of the created table (first one)
split_tables[[1]]

# To access each individual table
split_tables[["GlobalLEST"]]  # View table for GlobalLEST

# To export each table as a separate .csv
for (name in names(split_tables)) {
  write.csv(split_tables[[name]], paste0(name, "_filtered.csv"), row.names = FALSE)
} #saves each table with a filename based on time_group.

# To make sure each table is an object  (Create Individual Data Frame Objects)
for (name in names(split_tables)) {
  assign(paste0("df_", name), split_tables[[name]])
}
#18 dfs were created in the Environment (one for each territory)

#2.2. ANOVARM MAIN FACTORS in all dataframes (one for each territory) ----

# Run linear mixed-effects model (lme) on each split table
lme_results <- lapply(split_tables, function(df) {
  lme(outcome ~ time + group1sub2chr + rand1sub2supra, 
      random = ~1 | subject, 
      data = df)
})

#lapply() applies lme() to each split table.
#Each model is stored in the lme_results list.
#You can access a specific model summary:
summary(lme_results[["ACALEST"]])

# Double-check the analysis: making sure the analysis of all data frames from all territories in parallel time yield the same results as analysis of each individual data frame
# open  the table 
split_tables$ACALEST

#confirm  the results:
lme_results2ACALEST <-  lme(outcome ~ time + group1sub2chr + rand1sub2supra, 
                            random = ~1 | subject, 
                            data = split_tables$ACALEST)
summary(lme_results2ACALEST)


#The results for the main fixed factors and the interactions can be saved after the analysis of the interactions

#To export the results to CSV, ensuring that the names of the factors appear on each line: 

for (name in names(lme_results)) {
  model <- lme_results[[name]]
  
  if (inherits(model, "try-error")) next  # Skip failed models if you wrapped them in try()
  
  fixed_effects <- summary(model)$tTable  # Extract fixed effects table
  write.csv(as.data.frame(fixed_effects), paste0(name, "_lme_fixed_effects.csv"), row.names = TRUE)
}

#Output: csv files with results of main factors for each territory




# 2.3. ANOVARM interactions  ----
#i = interactions

# Run linear mixed-effects model interactions (lmei) on each split table
lmei_results = lapply(split_tables, function(df) {lme(outcome ~ time * group1sub2chr * rand1sub2supra, 
                                                      random = ~ 1|subject, 
                                                      data = df)
})
#lapply() applies lme() to each split table.
#Each model is stored in the lme_results list.
# THIS MODEL gave the results for MAIN FACTORS and INTERACTIONS


#You can access a specific model summary using for instance
summary(lmei_results[["ACALEST"]])

# To compare the results of parallel analysis of all territories, and the analysis of a single territory separately
#To view the table for ACALEST
split_tables$ACALEST

# The model below provided results for the main factors and interactions, for ACALEST alone
lmei_resultsCHECK = lme(outcome ~ time * group1sub2chr * rand1sub2supra, 
                        random = ~ 1|subject, 
                        data = split_tables$ACALEST)
summary(lmei_resultsCHECK)



# 3. Show ANOVARM results for main factors and  interactions for each territory ----
# Creates list with all anova results for each region with lapply
anova_results_lmei <- lapply(lmei_results, anova.lme)

# View ANOVA results for a specific time_group
anova_results_lmei[["GlobalLEST"]]


#If  want to visualize model fit for all tables:
lapply(lmei_results, plot)

# View model for a specific time_group - for instance, GlobalEST
summary(lmei_results[["GlobalLEST"]])

# Save all ANOVARM Results (Main factors and Interactions) to CSV: 
for (name in names(anova_results_lmei)) {
  anova_table <- as.data.frame(anova_results_lmei[[name]])  # Ensure it's a data frame
  write.csv(anova_table, paste0(name, "_lmei_anova_results.csv"), row.names = TRUE)
}
# This creates corresponding  .csv tables to results for each territory
#as.data.frame(anova_results_lmei[[name]]) #Ensures the ANOVA table is in data frame format.
#rownames_to_column(var = "Factor") #Moves factor names into a first column named "Factor".
