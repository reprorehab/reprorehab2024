import random 

# for loop
for i in range(3):
    print(f'This is the {i}th iteration')

# while loop
should_stop, n_iter, MAX_ITER = False, 0, 3
while not should_stop:
   print(f'This is the {n_iter}th iteration')
   n_iter += 1 
   should_stop = n_iter == MAX_ITER

# if statement
if True:
    print('if condition was met')

# if/else statement
if False:
    print('this will never print')
else:
    print('This will always print')

# if/elif/else statements
rand_value = random.randint(0, 10)
if rand_value < 3:
    print('rand_value less than 3')
elif rand_value >= 3 and rand_value < 5:
    print('rand_value between 3 and 5')
else:
    print('rand_value greater than or equal to 5')

# nested if 
name, grade = 'Duncan', 21
if name == 'Duncan':
    if grade > 16:
        print('more school, seriuosly?')
    else:
        print('less school, nice')

# match/case
LEVEL = 2
match LEVEL:
    case 1:
        print('Initial Level')
    case 2:
        print('Middle Level')
    case 3:
        print('Final Level')

# any
if any([True, False, False]):
    print('At least one is true')
else:
    print('All are false')

# all
if all([True, True, False]):
    print('All are true')
else:
    print('At least one is false')

# in
GROCERY_LIST = ['honey crisp apples', 'banana', 'chocolate almonds']
if 'banana' in GROCERY_LIST:
    print('Buy banana')
else:
    print('Do not buy banana')

PURCHASED_ITEMS = ['banana', 'giant nerds']
if 'candy' not in PURCHASED_ITEMS:
    print('On candy purge')
else:
    print('I breathe candy')
