import numpy as np
import pandas as pd # type: ignore
# Read in CSV using pandas
mycsv= pd.read_csv(r"C:\Users\skyla\Documents\ReproRehab\HalloweenExcel2023.csv")

# Read in TXT, Can also use read table to import TSV files
mytxt= pd.read_table(r"C:\Users\skyla\Documents\ReproRehab\HalloweenExcel2023.txt")

#Simple indexing using a list of numbers
numbered_list= [1, 2, 3, 4, 5, 6, 7, 8 , 9 ,10]
element= 4
element_index= (numbered_list.index(element)) #this will give me the index associated with the value assigned to element
print(element_index)

#Boolean Indexing using numpy
my_array= np.array([[1, 2, 3, 4, 5],  [6, 7, 8, 9, 10]])

#Find every element less than 5, it will only select the elements that satisfy the condition
print(my_array < 5)

#Extract the element in the first row second column
print('2nd element on 1st row: ', my_array[0, 1])

#Extract the element in the second row fifth column
print('5th element on 2nd row: ', my_array[1, 4])

