#example 1: of generating data with normal distribution
#standard way to import NumPy
import numpy as np
#generate random data for two independent samples
#initializes random number generator with a seed value 
np.random.seed(42)
group1 = np.random.normal(loc=50, scale=5, size=30)
group2 = np.random.normal(loc=55, scale=5, size= 30)
#print statements to visualize and check randomly generated data
print("Group 1 values:", group1)
print("Group 2 values:", group2)

#example 2a independent t-test using SciPy
from scipy.stats import ttest_ind 
t_stat, p_value = ttest_ind(group1, group2)
print("T-statistic:", t_stat)
print("P-value:", p_value)

#example 2b independent t-test using Pingouin 
import pingouin as pg
ttest_result = pg.ttest(group1, group2)
print(ttest_result)

p_value = ttest_result['p-val'][0]
print("P-value:", p_value)

#example 3: linear regression with statsmodels
#numpy has already been imported above. If not, you would need to import numpy in this step as well
import statsmodels.api as sm

# Generate sample data
np.random.seed(42)
x = np.random.normal(0, 1, 100)  # Predictor variable
y = 2 * x + np.random.normal(0, 0.5, 100)  # Dependent variable with added noise

# Add a constant to the predictor variable (for the intercept)
x = sm.add_constant(x)  # This adds a column of 1s for the intercept term

# Fit a linear regression model
model = sm.OLS(y, x).fit()

# Print the summary of the model
print(model.summary())

#indexing p-value of predictor variable from example #3
p_value_slope = model.pvalues[1]  
print("P-value for predictor variable:", p_value_slope)
