import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Simulate data for Group1 and Group2
group1 = np.random.normal(loc=50, scale=10, size=100)  # Mean=50, StdDev=10
group2 = np.random.normal(loc=60, scale=15, size=100)  # Mean=60, StdDev=15

colors1 = ['g']  # Colors for subplot 1
colors2 = ['orange']  # Colors for subplot 2


fig, axs = plt.subplots(1, 2, figsize=(12, 6))  # 1 row, 2 columns

sns.despine (top=True, right=True, left=False, bottom=False)

# Color for Group1
box1 = axs[0].boxplot(group1, patch_artist=True)  # Enable patch_artist for box coloring
for patch, color in zip(box1['boxes'], colors1):
    patch.set_facecolor(color)

# Boxplot for Group1
axs[0].set_title("Boxplot of Group1")
axs[0].set_ylim(0, 120)
axs[0].set_xlabel("Group1")
axs[0].set_ylabel("Values")
axs[0].grid(axis='y', linestyle='--', alpha=0.8, zorder=0)
 
# Color for Group2
box2 = axs[1].boxplot(group2, patch_artist=True)  # Enable patch_artist for box coloring
for patch, color in zip(box2['boxes'], colors2):
    patch.set_facecolor(color)

# Boxplot for Group2
axs[1].set_title("Boxplot of Group2")
axs[1].set_ylim(0, 120)
axs[1].set_xlabel("Group2")
axs[1].grid(axis='y', linestyle='--', alpha=0.8, zorder=0)

plt.tight_layout()
plt.show()