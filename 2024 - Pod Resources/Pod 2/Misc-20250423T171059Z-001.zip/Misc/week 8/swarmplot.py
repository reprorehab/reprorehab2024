import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Simulate data for Group1 and Group2
group1 = np.random.normal(loc=50, scale=10, size=100)  # Mean=50, StdDev=10
group2 = np.random.normal(loc=60, scale=15, size=100)  # Mean=60, StdDev=15

# Combine data into a DataFrame for use with seaborn
data = pd.DataFrame({
    "Values": np.concatenate([group1, group2]),
    "Group": ["Group1"] * len(group1) + ["Group2"] * len(group2)
})

# Plot swarm chart
plt.figure(figsize=(8, 6))
sns.swarmplot(x="Group", y="Values", data=data, size=6, alpha=0.7)

# Add labels and title
plt.title("Swarm Chart of Group1 and Group2")
plt.xlabel("Groups")
plt.ylabel("Values")

# Show the plot
plt.show()