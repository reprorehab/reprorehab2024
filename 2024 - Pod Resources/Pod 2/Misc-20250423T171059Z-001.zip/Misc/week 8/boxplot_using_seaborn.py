import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Set a random seed for reproducibility
np.random.seed(42)

# Simulate data for Group1 and Group2
group1 = np.random.normal(loc=50, scale=10, size=100)  # Mean=50, StdDev=10
group2 = np.random.normal(loc=60, scale=15, size=100)  # Mean=60, StdDev=15

# Combine data into a DataFrame for use with seaborn
data = pd.DataFrame({
    "Values": np.concatenate([group1, group2]), # combines group 1 and 2 into a single array. This array becomes the Values column in the DataFrame
    "Group": ["Group1"] * len(group1) + ["Group2"] * len(group2) # creates a list with the string "Group1" or "Group2" repeated for the number of elements in group 1 or 2
})

# Plot the boxplot
plt.figure(figsize=(8, 6)) # figsize=(width, height) of the entire figure
g = sns.boxplot(x="Group", y="Values", data=data, zorder=3)
sns.despine (top=True, right=True, left=False, bottom=False)

plt.ylim(0, 110)

# Add title and labels
plt.title("Boxplot of Two Groups")
plt.xlabel("Groups")
plt.ylabel("Values")

# Custom palette for the groups
palette = ['g', 'orange'] # Green for Group1, Orange for Group2
color_dict = dict(zip(data['Group'].unique(), palette))

# set color of boxplot
for i, artist in enumerate(g.artists):  # Iterate over the boxplot artists
    group = data['Group'].unique()[i]  # Get the group name corresponding to the box
    artist.set_facecolor(color_dict[group]) 

# Add grid lines
plt.grid(axis='y', linestyle='-', alpha=0.7, zorder=0)  # Grid on the y-axis with dashed lines; alpha # gives the degree of transparency of the gridlines  
plt.axhline(y=50, color='purple', linestyle='--', label='Median Line (y=50)')

# Show the plot
plt.show()