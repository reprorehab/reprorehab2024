import numpy as np
import matplotlib.pyplot as plt

# Simulate data for Group1 and Group2
group1 = np.random.normal(loc=50, scale=10, size=100)  # Mean=50, StdDev=10
group2 = np.random.normal(loc=60, scale=15, size=100)  # Mean=60, StdDev=15

# Plot histograms
plt.figure(figsize=(8, 6))


plt.hist(group1, bins=15, alpha=0.7, label="Group1", color='blue')  # Histogram for Group1
plt.hist(group2, bins=15, alpha=0.7, label="Group2", color='orange')  # Histogram for Group2

# Add labels, title, and legend
plt.title("Histogram of Group1 and Group2")
plt.xlabel("Values")
plt.ylabel("Frequency")
plt.legend()

plt.axvline(x=50, color='green', linestyle='--', label='Density Threshold')


# Show the plot
plt.show()