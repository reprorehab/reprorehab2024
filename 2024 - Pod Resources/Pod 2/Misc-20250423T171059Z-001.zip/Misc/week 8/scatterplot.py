import numpy as np
import matplotlib.pyplot as plt

# Simulate data (same as in the boxplot example)
data = {
    "Group1": np.random.normal(loc=50, scale=10, size=100),  # Mean=50, StdDev=10
    "Group2": np.random.normal(loc=60, scale=15, size=100),  # Mean=60, StdDev=15
}

# Assign numerical group positions for scatter plot
groups = list(data.keys())
positions = range(1, len(groups) + 1)

# Create scatter plot
plt.figure(figsize=(8, 6)) #plt.plot(x, y, marker='o') 
for i, group in enumerate(groups):
    y = data[group]
    x = np.random.normal(positions[i], 0.1, size=len(y))  # Add jitter to x-axis


    plt.scatter(x, y, marker='*', alpha=0.7, label=group)

# Add labels, title, and legend
plt.title("Scatter Plot of Simulated Data")
plt.xlabel("Groups")
plt.ylabel("Values")
plt.xticks(ticks=positions, labels=groups)
plt.legend()

# Add a trend line with slope=2, intercept=1
plt.axline((0, 1), slope=30, color="red", linestyle="--", label="Trend Line")

# Show the plot
plt.show()